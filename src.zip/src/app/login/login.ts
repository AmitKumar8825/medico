export class Login{
    public email:String='';
    public password:String='';
}