export class Appoint{

    public cName:String='';
	public  mobNo:String='';
	public  date:String='';
	public  slots:String='';
	public  email:String='';
	public  doctor:String='';
    public department:String='';
}